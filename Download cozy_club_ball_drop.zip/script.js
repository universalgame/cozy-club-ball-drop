const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");
const dropBtn = document.getElementById("dropBtn");
const loading = document.getElementById("loading");

canvas.width = 360;
canvas.height = 500;

let ball = { x: canvas.width / 2, y: 30, radius: 10, dy: 2 };
let dropped = false;

function drawBall() {
  ctx.beginPath();
  ctx.arc(ball.x, ball.y, ball.radius, 0, Math.PI * 2);
  ctx.fillStyle = "#ffd966";
  ctx.fill();
  ctx.closePath();
}

function drawPegs() {
  ctx.fillStyle = "#f5f5dc";
  for (let row = 0; row < 6; row++) {
    for (let col = 0; col < 6; col++) {
      const x = 50 + col * 50 + (row % 2 === 0 ? 25 : 0);
      const y = 80 + row * 50;
      ctx.beginPath();
      ctx.arc(x, y, 5, 0, Math.PI * 2);
      ctx.fill();
      ctx.closePath();
    }
  }
}

function draw() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  drawPegs();
  if (dropped) {
    drawBall();
    ball.y += ball.dy;
    if (ball.y > canvas.height - 30) {
      dropped = false;
      loading.textContent = "Ball has dropped!";
    }
  }
  requestAnimationFrame(draw);
}

dropBtn.addEventListener("click", () => {
  ball.x = canvas.width / 2;
  ball.y = 30;
  dropped = true;
  loading.textContent = "Dropping...";
});

draw();
